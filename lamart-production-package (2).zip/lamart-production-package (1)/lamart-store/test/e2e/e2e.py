"""
Browser tests for the LA MART storefront (needs: pip install playwright && playwright install chromium).
Run from the project folder:   python3 test/e2e/e2e.py
It serves public/ over local HTTP (like Netlify does) and checks, at desktop, tablet and mobile sizes:
console/page errors, failed requests, horizontal overflow, every internal link, every image, the cart,
checkout validation, preview mode honesty, and the live order/contact/newsletter flows against a MOCKED server
(no real order is ever created).
"""
import http.server, threading, functools, json, os, re, shutil, sys, tempfile
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
tmp = tempfile.mkdtemp(); site = os.path.join(tmp, 'public'); shutil.copytree(os.path.join(ROOT, 'public'), site)
h = open(os.path.join(site, 'index.html')).read()
live = h.replace("{code:'PK', name:'Pakistan',       enabled:false}", "{code:'PK', name:'Pakistan',       enabled:true}").replace("cod:{enabled:false", "cod:{enabled:true")
assert live != h, "could not switch on COD/PK in the test copy (CONFIG text changed?)"
open(os.path.join(site, 'live.html'), 'w').write(live)
# preview-mode copy: endpoints empty, as in the unpublished artifact
prev = re.sub(r"orderEndpoint:\s*'[^']*'", "orderEndpoint:''", h); prev = re.sub(r"contactEndpoint:\s*'[^']*'", "contactEndpoint:''", prev); prev = re.sub(r"newsletterEndpoint:\s*'[^']*'", "newsletterEndpoint:''", prev)
open(os.path.join(site, 'preview.html'), 'w').write(prev)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=site))
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{srv.server_address[1]}"

problems, passed = [], []
def check(cond, msg):
    (passed if cond else problems).append(msg)
    if not cond: print("  FAIL", msg)

ROUTES = ["", "shop", "cart", "about", "contact", "faq", "shipping", "privacy", "terms", "returns"]
PRODUCT_IDS = re.findall(r"\bid:'([a-z0-9-]+)',\s*category:", h)
check(len(PRODUCT_IDS) == 7, f"found 7 product ids in the page ({len(PRODUCT_IDS)})")
KNOWN = set(ROUTES) | set(PRODUCT_IDS) | {"home", "product", "app", "checkout"}   # "app" = the skip-link target (checked below); "product" links carry a data-id

def overflow(pg): return pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
def fill(pg):
    pg.fill("#coName", "Ayesha Khan"); pg.fill("#coEmail", "ayesha@example.com"); pg.fill("#coPhone", "0300 1234567")
    pg.fill("#coAddr", "12 Garden Road"); pg.fill("#coCity", "Lahore"); pg.fill("#coRegion", "Punjab"); pg.fill("#coZip", "54000")
def goto(pg, route): pg.evaluate(f"location.hash='#{route}'"); pg.wait_for_timeout(120)

def watch(pg, label):
    pg.on("pageerror", lambda e: problems.append(f"[{label}] PAGE ERROR {e}"))
    # fonts come from Google and may be unreachable in a sandbox; anything else is a real problem
    pg.on("console", lambda m: problems.append(f"[{label}] CONSOLE {m.text}") if m.type == "error" and "fonts.g" not in m.text and "ERR_" not in m.text and "Failed to load resource" not in m.text else None)
    pg.on("response", lambda r: problems.append(f"[{label}] HTTP {r.status} {r.url}") if r.url.startswith(BASE) and r.status >= 400 and not r.url.endswith(('/api/order', '/api/contact', '/api/newsletter')) else None)

with sync_playwright() as p:
    b = p.chromium.launch()
    for name, w, hh in (("desktop", 1366, 900), ("tablet", 820, 1180), ("mobile", 390, 844)):
        pg = b.new_page(viewport={'width': w, 'height': hh}); watch(pg, name)
        pg.goto(BASE + "/index.html"); pg.wait_for_timeout(300)
        check(pg.title().startswith("LA MART"), f"[{name}] page title")
        check(pg.locator("meta[name=description]").count() == 1, f"[{name}] meta description present")
        check("Everyday gadgets, beautifully chosen." in pg.inner_text("body"), f"[{name}] hero headline unchanged")
        check(pg.locator("header").count() >= 1 and pg.locator("nav, .nav, header").count() >= 1, f"[{name}] one header present")
        # --- every route: renders, no overflow; collect internal links ---
        links = set()
        for r in ROUTES + PRODUCT_IDS:
            goto(pg, r)
            check(len(pg.inner_text("main")) > 40, f"[{name}] route #{r or 'home'} renders content")
            check(overflow(pg) <= 0, f"[{name}] no horizontal scroll on #{r or 'home'} ({overflow(pg)}px)")
            for hr in pg.eval_on_selector_all("a[href^='#']", "els=>els.map(e=>e.getAttribute('href'))"): links.add(hr.lstrip('#'))
            for g in pg.eval_on_selector_all("[data-go]", "els=>els.map(e=>e.getAttribute('data-go'))"): links.add(g)
            for bad in pg.eval_on_selector_all("a[target=_blank]", "els=>els.filter(e=>!/noopener/.test(e.rel)).map(e=>e.href)"): check(False, f"[{name}] target=_blank without noopener: {bad}")
            # images: force eager loading, then confirm every image decoded
            pg.evaluate("document.querySelectorAll('img').forEach(i=>{i.loading='eager'})"); pg.wait_for_timeout(120)
            broken = pg.evaluate("Array.from(document.images).filter(i=>!(i.complete&&i.naturalWidth>0)).map(i=>(i.alt||i.src).slice(0,50))")
            check(not broken, f"[{name}] all images load on #{r or 'home'} {broken}")
        links = {l for l in links if l and l not in ('cart-open',)}
        unknown = sorted(l for l in links if l not in KNOWN and not l.startswith(('http', 'mailto', 'tel')))
        check(not unknown, f"[{name}] every internal link/data-go target is a real route: {unknown}")
        # --- shop, filter, search, cart ---
        goto(pg, "shop"); check(pg.locator(".pcard").count() == 7, f"[{name}] shop shows all 7 products ({pg.locator('.pcard').count()})")
        pg.fill("#shopQ", "flosser"); check(pg.locator(".pcard").count() == 1, f"[{name}] shop search narrows to 1"); pg.fill("#shopQ", "")
        pg.evaluate("localStorage.clear()"); goto(pg, "electric-lint-remover")
        (pg.locator(".sticky-buy [data-add]") if w < 700 else pg.locator(".buy-row [data-add]")).click()
        check(pg.inner_text("#cartCount") == "1", f"[{name}] add to cart updates the badge")
        goto(pg, "cart"); check("24.99" in pg.inner_text("main"), f"[{name}] cart shows the product price")
        pg.locator("[data-cq][data-d='1']").first.click(); check("49.98" in pg.inner_text("main"), f"[{name}] quantity change recalculates the total")
        pg.reload(); pg.wait_for_timeout(200); check(pg.inner_text("#cartCount") == "2", f"[{name}] cart survives a page reload")
        # --- checkout validation ---
        goto(pg, "cart"); pg.click("[data-go=checkout]"); check(overflow(pg) <= 0, f"[{name}] no horizontal scroll on checkout"); pg.click("#coSubmit")
        check(pg.locator(".field.bad").count() >= 5, f"[{name}] empty checkout is blocked with highlighted fields")
        pg.close()

        # --- preview mode (no endpoints): must be honest ---
        pg = b.new_page(viewport={'width': w, 'height': hh}); watch(pg, name + "-preview")
        pg.goto(BASE + "/preview.html"); pg.wait_for_timeout(200); goto(pg, "electric-lint-remover")
        (pg.locator(".sticky-buy [data-buy]") if w < 700 else pg.locator(".buy-row [data-buy]")).click()
        check("Preview checkout" in pg.inner_text("#coSubmit"), f"[{name}] preview: button says Preview checkout")
        check(pg.locator("#coCountry option").count() == 2, f"[{name}] Pakistan hidden until enabled")
        fill(pg); pg.click("#coSubmit"); pg.wait_for_timeout(150)
        t = pg.inner_text("main"); check("Checkout preview complete" in t and not re.search(r"LM-\d", t), f"[{name}] preview creates NO order number")
        goto(pg, "contact"); pg.fill("#cName", "Sam Lee"); pg.fill("#cEmail", "sam@example.com"); pg.fill("#cMsg", "Hello, a question."); pg.click("#contactForm button[type=submit]")
        check("not connected" in pg.inner_text("#cOk"), f"[{name}] preview contact form does not claim success")
        pg.fill("#newsEmail", "sam@example.com"); pg.click("#newsForm button[type=submit]")
        check("not connected" in pg.inner_text("#newsMsg"), f"[{name}] preview newsletter does not claim success")
        pg.close()

        # --- live mode against a MOCKED server ---
        pg = b.new_page(viewport={'width': w, 'height': hh}); watch(pg, name + "-live"); seen = {}
        def order(route):
            seen['body'] = json.loads(route.request.post_data); seen['ct'] = route.request.headers.get('content-type', '')
            route.fulfill(status=200, content_type="application/json", body=json.dumps({"orderNumber": "LM-1001", "total": 84.97, "currency": "USD"}))
        pg.route("**/api/order", order)
        pg.route("**/api/contact", lambda r: r.fulfill(status=200, content_type="application/json", body='{"ok":true}'))
        pg.route("**/api/newsletter", lambda r: r.fulfill(status=400, content_type="application/json", body='{"error":"Enter a valid email address."}'))
        pg.goto(BASE + "/live.html"); pg.wait_for_timeout(200); goto(pg, "electric-lint-remover")
        (pg.locator(".sticky-buy [data-add]") if w < 700 else pg.locator(".buy-row [data-add]")).click()
        goto(pg, "portable-water-flosser"); pg.click("[data-variant='White']")
        (pg.locator(".sticky-buy [data-buy]") if w < 700 else pg.locator(".buy-row [data-buy]")).click()
        check("Place order" in pg.inner_text("#coSubmit"), f"[{name}] live: button says Place order")
        check("Cash on Delivery" not in pg.inner_text("#payBox"), f"[{name}] live: COD hidden for US")
        pg.select_option("#coCountry", "PK"); check("Cash on Delivery" in pg.inner_text("#payBox"), f"[{name}] live: COD offered for PK only when enabled")
        fill(pg); pg.click("#coSubmit"); pg.wait_for_selector("text=Order confirmed")
        t = pg.inner_text("main"); check("LM-1001" in t and "$84.97" in t, f"[{name}] live: confirmation shows the server's number and total")
        o = seen['body']
        check(o['paymentMethod'] == 'cod' and len(o['items']) == 2 and not any('price' in k for it in o['items'] for k in it) and 'total' not in o, f"[{name}] browser sends ids/quantities only, never prices or totals")
        check(seen['ct'].startswith('application/json'), f"[{name}] order POST is application/json")
        check(pg.evaluate("JSON.parse(localStorage.getItem('lamart-cart')||'[]').length") == 0, f"[{name}] cart cleared after a confirmed order")
        goto(pg, "electric-lint-remover"); (pg.locator(".sticky-buy [data-buy]") if w < 700 else pg.locator(".buy-row [data-buy]")).click()
        pg.route("**/api/order", lambda r: r.fulfill(status=500, content_type="application/json", body='{"error":"We could not place your order. Please try again or contact us."}'))
        pg.select_option("#coCountry", "PK"); fill(pg); pg.click("#coSubmit"); pg.wait_for_selector("#coErr:has-text('could not place')")
        check(not re.search(r"LM-\d", " ".join(pg.locator("main").all_inner_texts())) and pg.locator("#coSubmit").is_enabled(), f"[{name}] server failure: no fake order number, can retry")
        goto(pg, "contact"); pg.fill("#cName", "Sam Lee"); pg.fill("#cEmail", "sam@example.com"); pg.fill("#cMsg", "Hello, a question."); pg.click("#contactForm button[type=submit]")
        pg.wait_for_selector("#cOk:has-text('has been sent')"); pg.fill("#newsEmail", "sam@example.com"); pg.click("#newsForm button[type=submit]"); pg.wait_for_selector("#newsMsg:has-text('valid email')")
        check(overflow(pg) <= 0, f"[{name}] live: no horizontal scroll")
        pg.close()
    b.close()
srv.shutdown(); shutil.rmtree(tmp, ignore_errors=True)
print(f"\n{len(passed)} checks passed, {len(problems)} problems")
if problems: print("\n".join(problems)); sys.exit(1)
print("E2E PASSED")
