-- Run against a Postgres that has migrations 0001+0002 and the Supabase roles. Prints PASS/FAIL lines.
\set ON_ERROR_STOP off
create or replace function pg_temp.expect_fail(label text, stmt text) returns void language plpgsql as $$
begin execute stmt; raise notice 'FAIL  % (was accepted)', label;
exception when others then raise notice 'PASS  % (%)', label, split_part(sqlerrm, E'\n', 1); end $$;

set role service_role;
select pg_temp.expect_fail('x', 'select 1/0');  -- sanity: helper reports errors
do $$ declare r jsonb; begin
  r := place_order('{"customer":{"name":"Test Buyer","email":"A@B.com","phone":"+1 555 0100"},
    "shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},
    "items":[{"id":"lint-remover","name":"Lint Remover","variant":"","qty":2,"unit_cents":2499},{"id":"flosser","name":"Flosser","variant":"White","qty":1,"unit_cents":3499}],
    "currency":"USD","payment_method":"cod"}');
  if (r->>'order_number')::int = 1001 and (r->>'total_cents')::int = 8497 then raise notice 'PASS  place_order -> LM-1001, total 8497';
  else raise notice 'FAIL  place_order result %', r; end if; end $$;
do $$ begin
  if (select count(*) from order_items) = 2 and (select sum(line_cents) from order_items) = 8497 then raise notice 'PASS  2 order_items rows, lines sum to total';
  else raise notice 'FAIL  order_items'; end if;
  if (select email from orders) = 'a@b.com' then raise notice 'PASS  email lower-cased'; else raise notice 'FAIL email case'; end if;
end $$;

select pg_temp.expect_fail('empty items rejected', $q$select place_order('{"customer":{"name":"Test Buyer","email":"x@y.com","phone":"1234567"},"shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[],"currency":"USD","payment_method":"cod"}')$q$);
select pg_temp.expect_fail('bad payment method rejected', $q$select place_order('{"customer":{"name":"Test Buyer","email":"x@y.com","phone":"1234567"},"shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[{"id":"a","name":"A","qty":1,"unit_cents":100}],"currency":"USD","payment_method":"bitcoin"}')$q$);
select pg_temp.expect_fail('bad country rejected', $q$select place_order('{"customer":{"name":"Test Buyer","email":"x@y.com","phone":"1234567"},"shipping":{"country":"USA","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[{"id":"a","name":"A","qty":1,"unit_cents":100}],"currency":"USD","payment_method":"cod"}')$q$);
select pg_temp.expect_fail('zero total rejected', $q$select place_order('{"customer":{"name":"Test Buyer","email":"x@y.com","phone":"1234567"},"shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[{"id":"a","name":"A","qty":1,"unit_cents":0}],"currency":"USD","payment_method":"cod"}')$q$);
select pg_temp.expect_fail('qty 0 rejected', $q$select place_order('{"customer":{"name":"Test Buyer","email":"x@y.com","phone":"1234567"},"shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[{"id":"a","name":"A","qty":0,"unit_cents":100}],"currency":"USD","payment_method":"cod"}')$q$);
select pg_temp.expect_fail('bad email rejected', $q$select place_order('{"customer":{"name":"Test Buyer","email":"nope","phone":"1234567"},"shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[{"id":"a","name":"A","qty":1,"unit_cents":100}],"currency":"USD","payment_method":"cod"}')$q$);
-- atomicity: a failing items insert (qty 0) must leave NO order row behind
do $$ begin if (select count(*) from orders) = 1 then raise notice 'PASS  failed orders left no partial rows (still 1 order)'; else raise notice 'FAIL  partial rows: % orders', (select count(*) from orders); end if; end $$;
select pg_temp.expect_fail('invalid status rejected', $q$update orders set status='hacked'$q$);
update orders set status='confirmed'; 
do $$ begin if (select updated_at > created_at from orders) then raise notice 'PASS  updated_at trigger fires'; else raise notice 'FAIL updated_at'; end if; end $$;
select pg_temp.expect_fail('message too short rejected', $q$insert into messages(name,email,message) values('Al','a@b.com','hi')$q$);
select pg_temp.expect_fail('duplicate subscriber rejected', $q$insert into subscribers(email) values('s@x.com'),('s@x.com')$q$);

-- throttle: 5 per email per hour (1 already placed for a@b.com)
do $$ declare i int; blocked boolean := false; begin
  for i in 1..6 loop begin
    perform place_order('{"customer":{"name":"Test Buyer","email":"a@b.com","phone":"+1 555 0100"},"shipping":{"country":"US","address":"1 Main St","city":"Austin","region":"TX","postal":"73301"},"items":[{"id":"a","name":"A","qty":1,"unit_cents":100}],"currency":"USD","payment_method":"cod"}');
  exception when others then if sqlerrm = 'rate_limited' then blocked := true; end if; end; end loop;
  if blocked and (select count(*) from orders where email='a@b.com') = 5 then raise notice 'PASS  throttle stops the 6th order/hour per email (5 stored)'; else raise notice 'FAIL throttle % %', blocked, (select count(*) from orders where email='a@b.com'); end if; end $$;
select place_order('{"customer":{"name":"Other Person","email":"c@d.com","phone":"1234567"},"shipping":{"country":"GB","address":"1 High St","city":"London","region":"Greater London","postal":"SW1A1AA"},"items":[{"id":"a","name":"A","qty":1,"unit_cents":100}],"currency":"USD","payment_method":"cod"}') is not null as other_email_ok;
reset role;
-- FK cascade
do $$ begin delete from orders where email='c@d.com'; if (select count(*) from order_items where name='A' and order_id not in (select id from orders)) = 0 then raise notice 'PASS  FK cascade removes items with their order'; else raise notice 'FAIL cascade'; end if; end $$;

-- privileges: public (anon) key must read/write/execute nothing
set role anon;
select pg_temp.expect_fail('anon cannot read orders',   'select * from orders');
select pg_temp.expect_fail('anon cannot insert orders', $q$insert into orders(customer_name) values('x')$q$);
select pg_temp.expect_fail('anon cannot read order_items', 'select * from order_items');
select pg_temp.expect_fail('anon cannot read subscribers', 'select * from subscribers');
select pg_temp.expect_fail('anon cannot call place_order', $q$select place_order('{}')$q$);
select pg_temp.expect_fail('anon cannot read admin view', 'select * from orders_admin');
reset role; set role authenticated;
select pg_temp.expect_fail('authenticated cannot read orders', 'select * from orders');
select pg_temp.expect_fail('authenticated cannot call place_order', $q$select place_order('{}')$q$);
reset role; set role service_role;
select order_number, status, item_count, total from orders_admin limit 2;
