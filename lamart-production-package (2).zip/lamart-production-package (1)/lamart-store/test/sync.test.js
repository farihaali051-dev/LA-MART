'use strict';
// Guards against the storefront and the server disagreeing: the page's products/prices/variants
// must match netlify/lib/catalog.json (the server's source of truth for prices).
const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
const m = html.match(/const PRODUCTS = (\[[\s\S]*?\n\]);/); assert.ok(m, 'PRODUCTS not found in public/index.html');
const page = vm.runInNewContext('(' + m[1] + ')');
const cat = require('../netlify/lib/catalog.json');
assert.strictEqual(page.length, cat.length, 'product count differs');
for (const p of page) {
  const c = cat.find(x => x.id === p.id); assert.ok(c, 'missing in catalog.json: ' + p.id);
  assert.strictEqual(c.name, p.name, 'name differs: ' + p.id);
  assert.strictEqual(c.price, p.price == null ? null : p.price, 'price differs: ' + p.id);
  assert.strictEqual(JSON.stringify(c.variants), JSON.stringify(p.variants), 'variants differ: ' + p.id);
  assert.strictEqual(c.prices.USD ?? null, p.price == null ? null : p.price, 'prices.USD differs: ' + p.id);
}
// the page must not ship secrets or call the database directly
assert.ok(!/service_role|sb_secret_|SUPABASE_SERVICE/.test(html), 'secret-looking text in public/index.html');
assert.ok(!/supabase\.co/.test(html), 'the page must not talk to Supabase directly');
for (const e of ['/api/order', '/api/contact', '/api/newsletter']) assert.ok(html.includes("'" + e + "'") || html.includes('"' + e + '"'), 'endpoint not wired: ' + e);
console.log('ok  storefront products/prices/variants match catalog.json (' + page.length + ' products); no secrets; endpoints wired');
