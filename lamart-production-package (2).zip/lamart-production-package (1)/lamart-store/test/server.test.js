'use strict';
// Runs the real handlers with a mocked database. No network, no secrets.
const assert = require('assert');
process.env.SUPABASE_URL = 'https://mock.supabase.co';
process.env.SUPABASE_SERVICE_KEY = 'mock-service-key';
process.env.COD_ENABLED = 'true'; process.env.COD_COUNTRIES = 'PK'; process.env.SHIP_COUNTRIES = 'US,GB,PK';

let calls = [];
const okRes = (v) => ({ ok: true, status: 200, text: async () => JSON.stringify(v), json: async () => v });
global.fetch = async (url, opts) => { calls.push({ url, opts }); return okRes(url.includes('place_order') ? { order_number: 1001, total_cents: JSON.parse(opts.body).p.items.reduce((a, i) => a + i.qty * i.unit_cents, 0), currency: JSON.parse(opts.body).p.currency } : null); };
const order = require('../netlify/functions/order').handler;
const contact = require('../netlify/functions/contact').handler;
const news = require('../netlify/functions/newsletter').handler;
const HDR = { 'content-type': 'application/json', origin: 'https://lamart.example', host: 'lamart.example' };
const post = (h, body, method = 'POST', headers = HDR) => h({ httpMethod: method, headers, body: typeof body === 'string' ? body : JSON.stringify(body) });
const good = () => ({ customer: { name: 'Ayesha Khan', email: 'A@Example.com', phone: '0300 1234567' },
  shipping: { country: 'PK', address: '12 Garden Road', address2: '', city: 'Lahore', region: 'Punjab', postal: '54000' },
  paymentMethod: 'cod', notes: '', items: [{ id: 'electric-lint-remover', variant: '', qty: 2 }, { id: 'portable-water-flosser', variant: 'White', qty: 1 }], website: '' });

(async () => {
  let r = await post(order, good());
  assert.strictEqual(r.statusCode, 200, r.body);
  let b = JSON.parse(r.body);
  assert.strictEqual(b.orderNumber, 'LM-1001'); assert.strictEqual(b.total, 84.97);   // 2 x 24.99 + 34.99, from the SERVER catalog
  const sent = JSON.parse(calls[0].opts.body).p;
  assert.ok(calls[0].url.endsWith('/rest/v1/rpc/place_order'));
  assert.strictEqual(sent.items.reduce((a, i) => a + i.qty * i.unit_cents, 0), 8497); assert.strictEqual(sent.customer.email, 'a@example.com'); assert.strictEqual(sent.currency, 'USD');
  assert.strictEqual(calls[0].opts.headers.apikey, 'mock-service-key');
  assert.strictEqual(calls[0].opts.headers.Authorization, undefined);          // sb_secret-style key: apikey header only
  process.env.SUPABASE_SERVICE_KEY = 'eyJlegacy.jwt.key'; await post(order, good());
  assert.strictEqual(calls[calls.length - 1].opts.headers.Authorization, 'Bearer eyJlegacy.jwt.key');   // legacy JWT key: both headers
  process.env.SUPABASE_SERVICE_KEY = 'mock-service-key';
  console.log('ok  valid COD order stored, total computed server-side, number from DB');

  let t = good(); t.items[0].price = 0.01; t.total = 0.01;                            // tampering attempt
  r = await post(order, t); assert.strictEqual(JSON.parse(r.body).total, 84.97);
  console.log('ok  client-sent price/total is ignored');

  for (const [name, mut, re] of [
    ['unknown product', x => x.items[0].id = 'nope', /not available/],
    ['launching-soon product (no price)', x => x.items[0].id = 'pet-hair-roller', /not available/],
    ['bad quantity', x => x.items[0].qty = 0, /quantity/i],
    ['huge quantity', x => x.items[0].qty = 1000, /quantity/i],
    ['fractional quantity', x => x.items[0].qty = 1.5, /quantity/i],
    ['bad variant', x => x.items[1].variant = 'Purple', /option/],
    ['empty cart', x => x.items = [], /cart/],
    ['bad email', x => x.customer.email = 'nope', /email/],
    ['bad phone', x => x.customer.phone = 'abc', /phone/],
    ['short address', x => x.shipping.address = '1', /address/],
    ['country not shipped', x => x.shipping.country = 'FR', /ship/],
    ['COD outside allowed country', x => x.shipping.country = 'US', /payment/],
    ['unknown payment method', x => x.paymentMethod = 'card', /payment/],
    ['honeypot filled', x => x.website = 'http://spam', /Invalid/]
  ]) { const x = good(); mut(x); r = await post(order, x); assert.strictEqual(r.statusCode, 400, name); assert.match(JSON.parse(r.body).error, re, name); }
  console.log('ok  14 invalid / hostile orders rejected');

  process.env.COD_ENABLED = 'false'; r = await post(order, good()); assert.strictEqual(r.statusCode, 400); process.env.COD_ENABLED = 'true';
  console.log('ok  COD refused while COD_ENABLED is not true');

  assert.strictEqual((await post(order, good(), 'GET')).statusCode, 405);
  assert.strictEqual((await post(order, '{not json')).statusCode, 400);
  assert.strictEqual((await post(order, 'x'.repeat(30000))).statusCode, 413);
  console.log('ok  wrong method / bad JSON / oversize body rejected');

  delete process.env.SUPABASE_SERVICE_KEY; r = await post(order, good()); assert.strictEqual(r.statusCode, 503);
  assert.ok(!r.body.includes('SUPABASE') && !r.body.includes('mock'));
  process.env.SUPABASE_SERVICE_KEY = 'mock-service-key';
  console.log('ok  missing config fails closed without leaking details');

  global.fetch = async () => ({ ok: false, status: 500, text: async () => '', json: async () => ({}) });
  r = await post(order, good()); assert.strictEqual(r.statusCode, 500); assert.ok(!r.body.includes('database'));
  console.log('ok  database failure returns a safe message, no order number');

  global.fetch = async (u, o) => { calls.push({ url: u, opts: o }); return okRes(null); };
  assert.strictEqual((await post(contact, { name: 'Sam', email: 'sam@x.com', message: 'Hello there', website: '' })).statusCode, 200);
  assert.ok(calls[calls.length - 1].url.endsWith('/rpc/submit_contact'));
  assert.strictEqual((await post(contact, { name: 'S', email: 'bad', message: 'x' })).statusCode, 400);
  assert.strictEqual((await post(news, { email: 'sam@x.com', website: '' })).statusCode, 200);
  assert.ok(calls[calls.length - 1].url.includes('on_conflict=email'));
  assert.strictEqual((await post(news, { email: 'bad' })).statusCode, 400);
  assert.strictEqual((await post(news, { email: 'a@b.com', website: 'bot' })).statusCode, 400);
  console.log('ok  contact + newsletter validate, store, and block bots');

  // --- CSRF / request hygiene ---
  global.fetch = async (u, o) => { calls.push({ url: u, opts: o }); return okRes({ order_number: 1002, total_cents: 100, currency: 'USD' }); };
  const n0 = calls.length;
  assert.strictEqual((await post(order, good(), 'POST', { 'content-type': 'text/plain', origin: 'https://lamart.example', host: 'lamart.example' })).statusCode, 415);
  assert.strictEqual((await post(order, good(), 'POST', { 'content-type': 'application/x-www-form-urlencoded', host: 'lamart.example' })).statusCode, 415);
  assert.strictEqual((await post(order, good(), 'POST', { ...HDR, origin: 'https://evil.example' })).statusCode, 403);
  assert.strictEqual((await post(order, good(), 'POST', { ...HDR, origin: 'null' })).statusCode, 403);
  assert.strictEqual((await post(contact, { name: 'Sam', email: 'sam@x.com', message: 'Hello there' }, 'POST', { ...HDR, origin: 'https://evil.example' })).statusCode, 403);
  assert.strictEqual(calls.length, n0, 'blocked requests must not reach the database');
  assert.strictEqual((await post(order, good(), 'POST', { 'Content-Type': 'application/json', host: 'lamart.example' })).statusCode, 200);   // no Origin (curl / live-check) is fine
  assert.strictEqual((await post(order, good(), 'POST', { ...HDR, 'content-type': 'application/json; charset=utf-8' })).statusCode, 200);
  process.env.ALLOWED_ORIGINS = 'www.lamart.example'; assert.strictEqual((await post(order, good(), 'POST', { ...HDR, origin: 'https://www.lamart.example', host: 'internal.netlify' })).statusCode, 200);
  assert.strictEqual((await post(order, good(), 'POST', { ...HDR, origin: 'https://evil.example', host: 'internal.netlify' })).statusCode, 403); delete process.env.ALLOWED_ORIGINS;
  process.env.URL = 'https://lamart.netlify.app'; assert.strictEqual((await post(order, good(), 'POST', { ...HDR, origin: 'https://lamart.netlify.app', host: 'internal.netlify' })).statusCode, 200); delete process.env.URL;
  console.log('ok  CSRF: wrong content-type or foreign Origin blocked before the database');

  // --- database throttle surfaces as 429 ---
  global.fetch = async () => ({ ok: false, status: 400, text: async () => '{"message":"rate_limited"}', json: async () => ({ message: 'rate_limited' }) });
  r = await post(order, good()); assert.strictEqual(r.statusCode, 429); assert.ok(!r.body.includes('rate_limited'));
  r = await post(contact, { name: 'Sam', email: 'sam@x.com', message: 'Hello there' }); assert.strictEqual(r.statusCode, 429);
  console.log('ok  DB throttle returns 429 with a friendly message');

  // --- per-country currency ---
  global.fetch = async (u, o) => { calls.push({ url: u, opts: o }); return okRes({ order_number: 1003, total_cents: 1, currency: JSON.parse(o.body).p.currency }); };
  const cat = require('../netlify/lib/catalog.json');
  process.env.COUNTRY_CURRENCY = 'PK:PKR';
  r = await post(order, good()); assert.strictEqual(r.statusCode, 400); assert.match(JSON.parse(r.body).error, /not available/);   // no PKR prices yet -> refused, never converted
  cat[0].prices.PKR = 7000;
  r = await post(order, good()); assert.strictEqual(r.statusCode, 400);                                                             // 2nd item still has no PKR price
  const ok2 = good(); ok2.items = [{ id: cat[0].id, variant: '', qty: 2 }];
  r = await post(order, ok2); assert.strictEqual(r.statusCode, 200, r.body);
  const sent2 = JSON.parse(calls[calls.length - 1].opts.body).p; assert.strictEqual(sent2.currency, 'PKR'); assert.strictEqual(sent2.items[0].unit_cents, 700000);
  delete cat[0].prices.PKR; delete process.env.COUNTRY_CURRENCY;
  console.log('ok  currency per country: unpriced currencies refused, priced ones stored in that currency');
  console.log('\nALL SERVER TESTS PASSED');
})().catch(e => { console.error('FAIL', e); process.exit(1); });
