'use strict';
/*
 * Optional: runs the REAL order/contact/newsletter handlers against a REAL Postgres that already has
 * migrations 0001 + 0002 and the Supabase roles (anon, authenticated, service_role).
 * A tiny stand-in for Supabase's REST layer forwards each call to psql, so the SQL functions and the JSON
 * the handlers send are exercised for real.  Usage:  PGHOST=/tmp/pgsock PGPORT=54329 PGUSER=postgres PGDATABASE=lm node test/db-integration.js
 * (Skipped automatically when PGDATABASE is not set.)
 */
const http = require('http'), assert = require('assert'), { execFileSync } = require('child_process');
if (!process.env.PGDATABASE) { console.log('skipped (PGDATABASE not set)'); process.exit(0); }
const psql = (sql, vars = {}) => execFileSync('psql', ['-X', '-q', '-tA', '-v', 'ON_ERROR_STOP=1', ...Object.entries(vars).flatMap(([k, v]) => ['-v', `${k}=${v}`])], { input: 'set role service_role;\n' + sql, encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }).replace(/^SET\n?/, '').trim();

const server = http.createServer((req, res) => {
  let b = ''; req.on('data', d => b += d); req.on('end', () => {
    try {
      assert.ok(req.headers.apikey, 'apikey header required');
      const m = req.url.match(/^\/rest\/v1\/rpc\/(\w+)$/);
      let out;
      if (m) { assert.ok(['place_order', 'submit_contact'].includes(m[1])); out = psql(`select public.${m[1]}(:'p'::jsonb);`, { p: JSON.stringify(JSON.parse(b).p) }); }
      else if (req.url.startsWith('/rest/v1/subscribers')) { psql(`insert into subscribers(email) values (lower(:'e')) on conflict (email) do nothing;`, { e: JSON.parse(b).email }); out = ''; }
      else throw new Error('unexpected ' + req.url);
      res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(out);
    } catch (e) {
      const msg = String(e.stderr || e.message); const rl = /rate_limited/.test(msg);
      res.writeHead(400, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: rl ? 'rate_limited' : msg.slice(0, 200) }));
    }
  });
});
server.listen(0, async () => {
  process.env.SUPABASE_URL = 'http://127.0.0.1:' + server.address().port; process.env.SUPABASE_SERVICE_KEY = 'sb_secret_local';
  process.env.COD_ENABLED = 'true'; process.env.COD_COUNTRIES = 'PK'; process.env.SHIP_COUNTRIES = 'US,GB,PK';
  const H = { 'content-type': 'application/json', host: 'x.test', origin: 'https://x.test' };
  const call = async (h, body) => { const r = await h({ httpMethod: 'POST', headers: H, body: JSON.stringify(body) }); return { status: r.statusCode, body: JSON.parse(r.body) }; };
  const order = require('../netlify/functions/order').handler, contact = require('../netlify/functions/contact').handler, news = require('../netlify/functions/newsletter').handler;
  const email = `it-${Date.now()}@example.com`;
  try {
    const o = { customer: { name: 'Integration Test', email: email.toUpperCase(), phone: '+92 300 1234567' }, shipping: { country: 'PK', address: '12 Test Road', address2: '', city: 'Lahore', region: 'Punjab', postal: '54000' },
      paymentMethod: 'cod', notes: 'it', website: '', items: [{ id: 'electric-lint-remover', variant: '', qty: 2, price: 0.01 }, { id: 'portable-water-flosser', variant: 'White', qty: 1 }] };
    let r = await call(order, o);
    assert.strictEqual(r.status, 200, JSON.stringify(r.body)); assert.match(r.body.orderNumber, /^LM-\d+$/); assert.strictEqual(r.body.total, 84.97); assert.strictEqual(r.body.currency, 'USD');
    const n = r.body.orderNumber.slice(3);
    assert.strictEqual(psql(`select count(*) from order_items i join orders o on o.id=i.order_id where o.order_number=${n};`), '2');
    assert.strictEqual(psql(`select email||'|'||total_cents||'|'||status from orders where order_number=${n};`), email + '|8497|new');
    console.log('ok  order handler -> place_order -> orders + 2 linked order_items, server total 84.97, number', r.body.orderNumber);
    r = await call(contact, { name: 'Test Sender', email, order: '', message: 'integration hello', website: '' }); assert.strictEqual(r.status, 200, JSON.stringify(r.body));
    assert.strictEqual(psql(`select count(*) from messages where email='${email}';`), '1');
    r = await call(news, { email, website: '' }); assert.strictEqual(r.status, 200); r = await call(news, { email, website: '' }); assert.strictEqual(r.status, 200);
    assert.strictEqual(psql(`select count(*) from subscribers where email='${email}';`), '1');
    console.log('ok  contact (submit_contact) and newsletter (duplicate ignored) stored for real');
    let last; for (let i = 0; i < 5; i++) last = await call(order, o);
    assert.strictEqual(last.status, 429, 'throttle should trip by the 6th order for one email'); console.log('ok  6th order in an hour for one email -> HTTP 429 from the real database throttle');
    psql(`delete from orders where email='${email}'; delete from messages where email='${email}'; delete from subscribers where email='${email}';`);
    console.log('\nDB INTEGRATION PASSED'); server.close();
  } catch (e) { console.error('FAIL', e.message); psql(`delete from orders where email='${email}';`); server.close(); process.exit(1); }
});
