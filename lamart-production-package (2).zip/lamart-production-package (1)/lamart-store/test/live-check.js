'use strict';
/*
 * LIVE check against YOUR real Supabase project. Run on your own computer:   node test/live-check.js
 * - Needs Node.js 18 or newer.
 * - Asks for your Project URL and Secret key. The key is typed hidden, never printed, never saved to a file.
 * - Runs the REAL order / contact / newsletter functions from this package, then reads the rows back
 *   from the database to prove they were saved.
 * - Leaves the test rows in place so you can look at them in Supabase > Table Editor.
 *   Add  --cleanup  to delete the rows this script created (the order number it used is not reused).
 * Every PASS/FAIL line below reflects a real response. Nothing is simulated.
 */
const readline = require('readline');
const cleanup = process.argv.includes('--cleanup');
let failures = 0;
const pass = (m) => console.log('  PASS  ' + m);
const fail = (m) => { failures++; console.log('  FAIL  ' + m); };
const check = (cond, ok, bad) => (cond ? pass(ok) : fail(bad || ok));

function ask(q, hidden) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) rl._writeToOutput = (s) => { if (s.includes(q)) rl.output.write(q); };
    rl.question(q, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); resolve(a.trim()); });
  });
}
function keyKind(k) {
  if (k.startsWith('sb_publishable_')) return 'publishable';
  if (k.startsWith('sb_secret_')) return 'secret';
  if (k.startsWith('eyJ')) { try { return JSON.parse(Buffer.from(k.split('.')[1], 'base64url').toString()).role || 'jwt'; } catch { return 'jwt'; } }
  return 'unknown';
}

(async () => {
  if (Number(process.versions.node.split('.')[0]) < 18) { console.error('Node.js 18 or newer is required. Installed: ' + process.version); process.exit(2); }
  console.log('\nLA MART live database check\n');
  let url = process.env.LIVE_SUPABASE_URL || await ask('Supabase Project URL (https://xxxx.supabase.co): ');
  const key = process.env.LIVE_SUPABASE_KEY || await ask('Supabase SECRET key (typing is hidden): ', true);
  url = url.replace(/\/+$/, '');
  if (!/^https?:\/\/[^\s]+$/.test(url)) { console.error('That does not look like a URL.'); process.exit(2); }
  const kind = keyKind(key);
  if (kind === 'publishable' || kind === 'anon') { console.error('\nSTOP: that is the PUBLIC key (' + kind + '). Use the Secret key (sb_secret_...) or the legacy service_role key.'); process.exit(2); }
  if (kind === 'unknown') console.log('  note: key format not recognised, trying anyway');

  process.env.SUPABASE_URL = url; process.env.SUPABASE_SERVICE_KEY = key;
  // Test-only server rules (in this process only; your real settings live in Netlify).
  process.env.COD_ENABLED = 'true'; process.env.COD_COUNTRIES = 'PK'; process.env.SHIP_COUNTRIES = 'US,GB,PK'; delete process.env.COUNTRY_CURRENCY;

  const auth = key.startsWith('eyJ') ? { Authorization: 'Bearer ' + key } : {};
  const rest = async (method, path, body) => {
    const r = await fetch(`${url}/rest/v1/${path}`, { method, headers: { apikey: key, ...auth, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch {}
    return { ok: r.ok, status: r.status, json: j };
  };
  const call = async (h, body) => { const r = await h({ httpMethod: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.statusCode, body: JSON.parse(r.body) }; };
  const created = { orders: [], messages: [], subscribers: [] };   // deleting an order also deletes its order_items (cascade)
  const stamp = Date.now();

  console.log('\n1) Connection + tables');
  for (const t of ['orders', 'order_items', 'messages', 'subscribers']) {
    const r = await rest('GET', `${t}?select=id&limit=1`);
    check(r.ok, `table "${t}" reachable with your key`, `table "${t}" NOT reachable (HTTP ${r.status}) ${r.json && r.json.message ? '- ' + r.json.message : ''}`);
  }
  if (failures) { console.log('\nStopping: fix the connection first (check the URL, and that you ran schema.sql, or migrations 0001 then 0002).'); process.exit(1); }

  console.log('\n2) Test order (real order function -> real database)');
  const order = require('../netlify/functions/order').handler;
  const email = `lamart-test-${stamp}@example.com`;
  const payload = {
    customer: { name: 'TEST Order Delete Me', email: email.toUpperCase(), phone: '+92 300 1234567' },
    shipping: { country: 'PK', address: '12 Test Road', address2: 'Flat 4', city: 'Lahore', region: 'Punjab', postal: '54000' },
    paymentMethod: 'cod', notes: 'LIVE CHECK ' + stamp,
    items: [{ id: 'electric-lint-remover', variant: '', qty: 2, price: 0.01 }, { id: 'portable-water-flosser', variant: 'White', qty: 1, price: 0.01 }],
    total: 0.01, website: ''                                  // price/total deliberately wrong: the server must ignore them
  };
  const res = await call(order, payload);
  check(res.status === 200, 'order accepted (HTTP 200)', `order rejected: HTTP ${res.status} ${JSON.stringify(res.body)}`);
  const num = res.body && res.body.orderNumber;
  check(/^LM-\d+$/.test(num || ''), `order number generated by the database: ${num}`, 'no valid order number returned');
  check(res.body && res.body.total === 84.97, 'server total = 84.97 (2 x 24.99 + 34.99), ignoring the 0.01 sent by the "browser"', `server total was ${res.body && res.body.total}, expected 84.97`);
  if (/^LM-\d+$/.test(num || '')) {
    const n = num.slice(3);
    const rr = await rest('GET', `orders?order_number=eq.${n}&select=*`);
    const row = rr.json && rr.json[0];
    check(!!row, `row found in the database for ${num}`, 'order was NOT found in the database');
    if (row) {
      created.orders.push(row.id);
      check(row.total_cents === 8497 && row.currency === 'USD', `stored total ${row.total_cents} cents ${row.currency} (price from server catalog)`, `stored total wrong: ${row.total_cents}`);
      const it = row.items || [];
      check(it.length === 2 && it[0].unit_cents === 2499 && it[1].unit_cents === 3499 && it[1].variant === 'White', 'line items stored with server prices: 24.99 x2 and 34.99 (White)', 'line items wrong: ' + JSON.stringify(it));
      check(row.customer_name === 'TEST Order Delete Me' && row.email === email && row.phone === '+92 300 1234567', 'customer name, email (lower-cased) and phone saved', 'customer details wrong');
      check(row.address === '12 Test Road' && row.address2 === 'Flat 4' && row.city === 'Lahore' && row.region === 'Punjab' && row.postal === '54000' && row.country === 'PK', 'full shipping address saved', 'shipping address wrong');
      const li = await rest('GET', `order_items?order_id=eq.${row.id}&select=*&order=id`);
      const L = li.json || [];
      check(L.length === 2 && L[0].product_id === 'electric-lint-remover' && L[0].qty === 2 && L[0].unit_cents === 2499 && L[0].line_cents === 4998 && L[1].variant === 'White' && L[1].line_cents === 3499, 'order_items table has 2 linked rows (qty, server unit price, line total)', 'order_items rows wrong: ' + JSON.stringify(L));
      check(L.reduce((a, x) => a + x.line_cents, 0) === row.total_cents, 'sum of order_items lines equals the order total', 'order_items do not add up to the order total');
      const av = await rest('GET', `orders_admin?order_number=eq.LM-${n}&select=*`);
      check(av.json && av.json[0] && Number(av.json[0].total) === 84.97 && Number(av.json[0].item_count) === 3, 'orders_admin view shows LM-' + n + ' total 84.97 and 3 items', 'orders_admin view wrong: ' + JSON.stringify(av.json));
      check(row.payment_method === 'cod' && row.status === 'new' && !!row.created_at, 'payment method, status "new" and timestamp saved', 'payment/status/timestamp wrong');
    }
  }
  const badEmail = `lamart-reject-${stamp}@example.com`;
  const bad = await call(order, { ...payload, customer: { ...payload.customer, email: badEmail }, items: [{ id: 'not-a-product', variant: '', qty: 1 }] });
  const badRows = await rest('GET', `orders?email=eq.${encodeURIComponent(badEmail)}&select=id`);
  check(bad.status === 400 && badRows.json && badRows.json.length === 0, 'order with an unknown product is rejected (HTTP 400) and nothing is stored', `bad order handling wrong: HTTP ${bad.status}, rows stored: ${badRows.json ? badRows.json.length : '?'}`);

  console.log('\n3) Contact form');
  const contact = require('../netlify/functions/contact').handler;
  const c = await call(contact, { name: 'Test Sender', email, order: String(num || ''), message: 'LIVE CHECK message ' + stamp, website: '' });
  check(c.status === 200, 'contact accepted (HTTP 200)', `contact rejected: HTTP ${c.status} ${JSON.stringify(c.body)}`);
  const cr = await rest('GET', `messages?email=eq.${encodeURIComponent(email)}&select=*`);
  check(cr.json && cr.json.length === 1 && cr.json[0].message === 'LIVE CHECK message ' + stamp, 'message found in the database with the right text', 'message NOT found in the database');
  if (cr.json && cr.json[0]) created.messages.push(cr.json[0].id);

  console.log('\n4) Newsletter');
  const news = require('../netlify/functions/newsletter').handler;
  const n1 = await call(news, { email, website: '' }), n2 = await call(news, { email, website: '' });
  check(n1.status === 200 && n2.status === 200, 'subscribing twice with the same email both return HTTP 200', `newsletter failed: ${n1.status}/${n2.status} ${JSON.stringify(n1.body)}`);
  const nr = await rest('GET', `subscribers?email=eq.${encodeURIComponent(email)}&select=*`);
  check(nr.json && nr.json.length === 1, 'exactly ONE subscriber row stored (duplicate ignored)', `subscriber rows: ${nr.json ? nr.json.length : 'none'}`);
  if (nr.json && nr.json[0]) created.subscribers.push(nr.json[0].id);

  console.log('\n5) Public (browser) key cannot touch your data  [optional: press Enter to skip]');
  const pub = process.env.LIVE_SUPABASE_PUBLIC_KEY !== undefined ? process.env.LIVE_SUPABASE_PUBLIC_KEY : await ask('Publishable / anon key (public, safe to type): ', false);
  if (pub) {
    const ph = { apikey: pub, 'Content-Type': 'application/json', ...(pub.startsWith('eyJ') ? { Authorization: 'Bearer ' + pub } : {}) };
    const g = await fetch(`${url}/rest/v1/orders?select=*`, { headers: ph }); const gj = await g.json().catch(() => null);
    check(Array.isArray(gj) ? gj.length === 0 : !g.ok, 'public key reads ZERO orders (your real order exists, so it is being hidden)', 'public key could READ orders: this is a security problem');
    const w = await fetch(`${url}/rest/v1/orders`, { method: 'POST', headers: ph, body: JSON.stringify({ customer_name: 'x', email: 'x@x.com', phone: '1234567', country: 'US', address: 'x', city: 'x', region: 'x', postal: 'x', items: [], total_cents: 1, payment_method: 'cod' }) });
    check(!w.ok, `public key cannot write an order (HTTP ${w.status})`, 'public key could WRITE an order: this is a security problem');
    const rp = await fetch(`${url}/rest/v1/rpc/place_order`, { method: 'POST', headers: ph, body: JSON.stringify({ p: {} }) });
    check(!rp.ok, `public key cannot call place_order (HTTP ${rp.status})`, 'public key could CALL place_order: this is a security problem');
    const oi = await fetch(`${url}/rest/v1/order_items?select=*`, { headers: ph }); const oij = await oi.json().catch(() => null);
    check(Array.isArray(oij) ? oij.length === 0 : !oi.ok, 'public key reads ZERO order_items', 'public key could READ order_items: this is a security problem');
  } else console.log('  skipped');

  if (cleanup) {
    console.log('\nCleanup');
    for (const [t, ids] of Object.entries(created)) for (const id of ids) { const d = await rest('DELETE', `${t}?id=eq.${id}`); check(d.ok, `deleted test row from ${t}`, `could not delete from ${t}`); }
  } else console.log('\nTest rows were left in place. Look at them in Supabase > Table Editor (orders, messages, subscribers). Run again with --cleanup to delete them.');

  console.log(failures ? `\nRESULT: ${failures} check(s) FAILED. Send me this whole output (it contains no secrets).` : `\nRESULT: ALL CHECKS PASSED against ${new URL(url).host}`);
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.error('\nUnexpected error: ' + e.message); process.exit(1); });
