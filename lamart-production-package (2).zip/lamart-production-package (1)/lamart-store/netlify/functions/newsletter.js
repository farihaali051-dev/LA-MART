'use strict';
const { validateSubscriber } = require('../lib/validate');
const { json, readBody, insert, fail } = require('../lib/http');

exports.handler = async (event) => {
  const { error, data } = readBody(event); if (error) return error;
  const v = validateSubscriber(data);
  if (!v.ok) return json(400, { error: v.errors.join(' ') });
  try { await insert('subscribers?on_conflict=email', { email: v.email }, { Prefer: 'resolution=ignore-duplicates,return=minimal' }); return json(200, { ok: true }); }
  catch (e) { return fail(e, 'newsletter', 'We could not save your email. Please try again later.'); }
};
