'use strict';
const { validateContact } = require('../lib/validate');
const { json, readBody, rpc, fail } = require('../lib/http');

exports.handler = async (event) => {
  const { error, data } = readBody(event); if (error) return error;
  const v = validateContact(data);
  if (!v.ok) return json(400, { error: v.errors.join(' ') });
  try { await rpc('submit_contact', { p: v.message }); return json(200, { ok: true }); }
  catch (e) { return fail(e, 'contact', 'We could not send your message. Please email us instead.'); }
};
