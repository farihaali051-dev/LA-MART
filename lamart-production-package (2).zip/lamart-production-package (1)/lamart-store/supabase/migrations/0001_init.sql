-- Run once in Supabase: SQL Editor > New query > paste > Run.
-- Row Level Security is ON with NO policies, so the public (anon) key can read or write nothing.
-- Only the server-side service key used by the Netlify functions can insert. Read orders in the Supabase dashboard.

create table if not exists orders (
  id bigint generated always as identity primary key,
  order_number bigint generated always as identity (start with 1001),
  created_at timestamptz not null default now(),
  status text not null default 'new',
  customer_name text not null, email text not null, phone text not null,
  country text not null, address text not null, address2 text, city text not null, region text not null, postal text not null,
  items jsonb not null, total_cents integer not null, currency text not null default 'USD',
  payment_method text not null, notes text
);
create table if not exists messages (
  id bigint generated always as identity primary key, created_at timestamptz not null default now(),
  name text not null, email text not null, "order" text, message text not null
);
create table if not exists subscribers (
  id bigint generated always as identity primary key, created_at timestamptz not null default now(),
  email text not null unique
);
alter table orders enable row level security;
alter table messages enable row level security;
alter table subscribers enable row level security;
