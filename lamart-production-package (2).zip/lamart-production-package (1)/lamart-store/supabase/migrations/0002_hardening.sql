-- LA MART migration 0002: constraints, indexes, order_items (linked to orders), status workflow,
-- atomic place_order(), contact throttle, admin view, and tighter permissions.
-- Safe to run more than once. Run it in Supabase: SQL Editor > New query > paste > Run.

-- ---------- 1. updated_at ----------
alter table orders add column if not exists updated_at timestamptz not null default now();
create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
drop trigger if exists orders_set_updated_at on orders;
create trigger orders_set_updated_at before update on orders for each row execute function public.set_updated_at();

-- ---------- 2. constraints (drop first so this file can be re-run) ----------
alter table orders
  drop constraint if exists orders_status_check,   drop constraint if exists orders_total_check,
  drop constraint if exists orders_currency_check, drop constraint if exists orders_country_check,
  drop constraint if exists orders_payment_check,  drop constraint if exists orders_email_check,
  drop constraint if exists orders_items_check,    drop constraint if exists orders_lengths_check;
alter table orders
  add constraint orders_status_check   check (status in ('new','confirmed','packed','shipped','delivered','cancelled')),
  add constraint orders_total_check    check (total_cents > 0),
  add constraint orders_currency_check check (currency ~ '^[A-Z]{3}$'),
  add constraint orders_country_check  check (country ~ '^[A-Z]{2}$'),
  add constraint orders_payment_check  check (payment_method in ('cod','card')),
  add constraint orders_email_check    check (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' and length(email) <= 120),
  add constraint orders_items_check    check (jsonb_typeof(items) = 'array' and jsonb_array_length(items) between 1 and 20),
  add constraint orders_lengths_check  check (length(customer_name) between 2 and 80 and length(phone) between 7 and 20
                                              and length(address) between 5 and 120 and length(city) between 2 and 60
                                              and length(region) between 2 and 60 and length(postal) between 3 and 12
                                              and coalesce(length(notes), 0) <= 500);
alter table messages
  drop constraint if exists messages_email_check, drop constraint if exists messages_lengths_check;
alter table messages
  add constraint messages_email_check   check (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' and length(email) <= 120),
  add constraint messages_lengths_check check (length(name) between 2 and 80 and length(message) between 5 and 2000 and coalesce(length("order"), 0) <= 40);
alter table subscribers
  drop constraint if exists subscribers_email_check;
alter table subscribers
  add constraint subscribers_email_check check (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' and length(email) <= 120);

-- ---------- 3. indexes ----------
create unique index if not exists orders_order_number_key on orders (order_number);
create index if not exists orders_created_at_idx on orders (created_at desc);
create index if not exists orders_email_idx      on orders (email);
create index if not exists orders_status_idx     on orders (status);
create index if not exists messages_created_at_idx on messages (created_at desc);
create index if not exists messages_email_idx      on messages (email);

-- ---------- 4. order_items: one row per product line, linked to its order ----------
create table if not exists order_items (
  id          bigint generated always as identity primary key,
  order_id    bigint not null references orders(id) on delete cascade,
  product_id  text not null,
  name        text not null,
  variant     text not null default '',
  qty         integer not null check (qty between 1 and 99),
  unit_cents  integer not null check (unit_cents >= 0),
  line_cents  integer generated always as (qty * unit_cents) stored
);
create index if not exists order_items_order_id_idx   on order_items (order_id);
create index if not exists order_items_product_id_idx on order_items (product_id);
alter table order_items enable row level security;

-- ---------- 5. place_order(): order + items in ONE transaction, with abuse limits ----------
-- Called only by your server (service key). The server supplies prices from its own catalog;
-- the database recomputes the total from the lines and refuses anything inconsistent.
create or replace function public.place_order(p jsonb) returns jsonb
language plpgsql set search_path = public as $$
declare
  v_email text := lower(p #>> '{customer,email}');
  v_id bigint; v_number bigint; v_total integer; v_currency text := coalesce(p->>'currency', 'USD');
begin
  if (select count(*) from orders where email = v_email and created_at > now() - interval '1 hour') >= 5
     or (select count(*) from orders where created_at > now() - interval '1 hour') >= 200 then
    raise exception 'rate_limited' using errcode = 'P0001';
  end if;
  if jsonb_typeof(p->'items') <> 'array' or jsonb_array_length(p->'items') = 0 then
    raise exception 'empty_order' using errcode = 'P0001';
  end if;
  select sum((i->>'qty')::int * (i->>'unit_cents')::int) into v_total from jsonb_array_elements(p->'items') i;

  insert into orders (customer_name, email, phone, country, address, address2, city, region, postal,
                      items, total_cents, currency, payment_method, notes, status)
  values (p #>> '{customer,name}', v_email, p #>> '{customer,phone}',
          p #>> '{shipping,country}', p #>> '{shipping,address}', nullif(p #>> '{shipping,address2}', ''),
          p #>> '{shipping,city}', p #>> '{shipping,region}', p #>> '{shipping,postal}',
          p->'items', v_total, v_currency, p->>'payment_method', nullif(p->>'notes', ''), 'new')
  returning id, order_number into v_id, v_number;

  insert into order_items (order_id, product_id, name, variant, qty, unit_cents)
  select v_id, i->>'id', i->>'name', coalesce(i->>'variant', ''), (i->>'qty')::int, (i->>'unit_cents')::int
  from jsonb_array_elements(p->'items') i;

  return jsonb_build_object('order_number', v_number, 'total_cents', v_total, 'currency', v_currency);
end $$;

create or replace function public.submit_contact(p jsonb) returns jsonb
language plpgsql set search_path = public as $$
begin
  if (select count(*) from messages where email = lower(p->>'email') and created_at > now() - interval '1 hour') >= 5
     or (select count(*) from messages where created_at > now() - interval '1 hour') >= 200 then
    raise exception 'rate_limited' using errcode = 'P0001';
  end if;
  insert into messages (name, email, "order", message) values (p->>'name', lower(p->>'email'), nullif(p->>'order', ''), p->>'message');
  return jsonb_build_object('ok', true);
end $$;

-- ---------- 6. admin view: easy order management in the Supabase Table Editor ----------
create or replace view public.orders_admin with (security_invoker = true) as
  select 'LM-' || o.order_number as order_number, o.created_at, o.status, o.customer_name, o.phone, o.email,
         o.country, o.city, o.address, o.payment_method,
         (select sum(qty) from order_items i where i.order_id = o.id) as item_count,
         o.currency, (o.total_cents / 100.0)::numeric(10,2) as total, o.notes
  from orders o order by o.created_at desc;

-- ---------- 7. permissions: only your server (service_role) can touch any of this ----------
revoke all on orders, order_items, messages, subscribers, orders_admin from anon, authenticated;
revoke all on function public.place_order(jsonb), public.submit_contact(jsonb) from public, anon, authenticated;
grant execute on function public.place_order(jsonb), public.submit_contact(jsonb) to service_role;
alter table orders enable row level security; alter table messages enable row level security; alter table subscribers enable row level security;
