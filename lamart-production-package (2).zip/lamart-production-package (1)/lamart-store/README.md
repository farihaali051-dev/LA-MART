# LA MART: production package

A static storefront (`public/index.html`) plus three small server functions (orders, contact, newsletter)
that store data in a database. Host: **Netlify**. Database: **Supabase**.

## 1. Status (honest)

| Area | Status |
|---|---|
| Storefront: design, 7 products, search, categories, cart, checkout form, responsive | Complete. 235 automated browser checks pass at desktop, tablet and mobile |
| Server functions (`/api/order`, `/api/contact`, `/api/newsletter`): validation, server-side pricing, CSRF checks, safe errors | Complete. Unit-tested with a mocked database, and integration-tested against a **real local PostgreSQL 16** |
| Database schema, constraints, indexes, linked `order_items`, atomic `place_order()`, throttle, permissions | Complete. Tested on real PostgreSQL 16 (25 checks). **Your Supabase project has 0001 applied; apply 0002 (section 3, step 1)** |
| Supabase REST + Netlify runtime | **Not yet run live.** `node test/live-check.js` proves it against your real project (section 3, step 2) |
| Cash on Delivery | Architecture built, **switched off** until you confirm your business supports it |
| Online card payment | **Not built, by design.** Orders already have a `payment_method` and status workflow, so a gateway can be added (section 7) |
| Hosting, domain, HTTPS | **Not done.** Needs your Netlify / registrar accounts (sections 3-4) |
| Order emails / notifications | Not built (optional) |

## 2. Why a backend is required
`localStorage` exists only in one customer's browser; it cannot be your order book. Orders, messages and sign-ups go to a
server-side database. The functions **recompute every price on the server** from `netlify/lib/catalog.json`, and the database
re-adds the lines, so a customer cannot change a price in their browser.

## 3. Deploy
1. **Database (Supabase).** SQL Editor > New query > paste `supabase/migrations/0002_hardening.sql` > Run.
   (A brand-new project: run `schema.sql` instead, which is 0001 + 0002.) Safe to run twice.
2. **Prove it live (on your computer, Node 18+):** `node test/live-check.js`. It asks for the Project URL and Secret key (typed hidden, never saved or printed),
   runs the real functions against your real database, reads the rows back, and checks the public key is locked out. Add `--cleanup` to delete its test rows.
3. **Code.** Put this folder in a GitHub repo (private is fine). Never commit real keys (`.gitignore` covers `.env`).
4. **Host.** netlify.com > Add new site > Import from GitHub. Settings come from `netlify.toml`.
5. **Secrets.** Netlify > Site configuration > Environment variables. Add what `.env.example` lists:
   `SUPABASE_URL`, `SUPABASE_SERVICE_KEY` (the `sb_secret_...` key), `SHIP_COUNTRIES`, `COD_ENABLED`, `COD_COUNTRIES`; optional `COUNTRY_CURRENCY`, `ALLOWED_ORIGINS`. Redeploy after changes.
6. **First live order.** Open the `*.netlify.app` URL, place a test order, look at Supabase > Table Editor > `orders_admin` (one readable row per order) and `order_items`. Delete test rows before launch.

Order management: change `status` in `orders` (new, confirmed, packed, shipped, delivered, cancelled). `updated_at` updates by itself.

## 4. Custom domain and HTTPS
1. Buy a domain at a registrar. 2. Netlify > Domain management > Add a domain.
3. At the registrar's DNS panel add what Netlify shows (normally `www` CNAME to `<site>.netlify.app`; bare domain A record to the IP shown, currently `75.2.60.5`, or switch to Netlify DNS).
4. Netlify > HTTPS > Provision certificate (free, auto-renewing); enable Force HTTPS. If the API ever answers 403 on the custom domain, add the domain to `ALLOWED_ORIGINS`.

## 5. Currency (US / UK / Pakistan)
The storefront and `catalog.json` are **USD**. The Shopify store is PKR and its gateway blocks USD; this site does not use Shopify checkout.
The server supports one currency per shipping country: set `COUNTRY_CURRENCY=US:USD,GB:GBP,PK:PKR` and add `"prices": {"USD":24.99,"GBP":…,"PKR":…}` per product in `catalog.json`.
A product is only sold in a currency that has a price you entered. **Nothing is ever converted automatically, and no price has been changed.**
Before selling in GBP/PKR the page must also display those prices (it shows USD only today), so that is a follow-up once you supply the price lists.

## 6. Turning on Cash on Delivery / Pakistan
Only after you confirm you can deliver there and accept cash:
- `public/index.html`: `CONFIG.shipTo` Pakistan `enabled:true`; `CONFIG.payments.cod.enabled:true`.
- Netlify env: `SHIP_COUNTRIES=US,GB,PK`, `COD_ENABLED=true`, `COD_COUNTRIES=PK`.
The server enforces its own copy of these rules, so editing the page alone is not enough.
Shipping fees are not modelled: totals exclude shipping and the page says it is confirmed before dispatch.

## 7. Adding a card payment later
Needs your account with a provider. Typical shape: a server function creates a payment session from the same server-priced cart, a webhook (signed with a secret kept in Netlify env) marks the order paid, and the `payment_method` check in `0002` is widened. Keys never go in the page.

## 8. Security (in place)
- No keys in the browser (`test/sync.test.js` fails if secret-looking text or Supabase calls appear in the page). Row Level Security is on with no policies and the public roles have all privileges revoked, so the public key can read, write and execute nothing.
- Prices, totals, order numbers server-side only; quantity, variant, country and every field validated, and again by database CHECK constraints.
- `place_order()` saves the order and its items in one transaction, and limits 5 orders per email and 200 per hour.
- JSON-only POST, same-origin check (CSRF), body-size limit, honeypot, errors that never reveal internals.
- Security headers + Content-Security-Policy (`netlify.toml`).
- Not included: CAPTCHA. Add Cloudflare Turnstile if spam appears.
- You hold customers' personal data: make sure the Privacy Policy matches what you really do and check the laws that apply to you.

## 9. Before you go live (owner checklist)
- [ ] Apply migration 0002; run `node test/live-check.js`
- [ ] Real prices for the 4 "Launching soon" products (`price` in `public/index.html` AND `netlify/lib/catalog.json`)
- [ ] Decide currency setup (section 5), COD and Pakistan shipping (section 6)
- [ ] Review Shipping, Returns, Privacy and Terms wording (written generically); social URLs in `SITE.social`
- [ ] Netlify site, env vars, domain, HTTPS; one real test order; delete test data

## 10. Keeping files in sync
`netlify/lib/catalog.json` holds the prices the server trusts. `npm test` fails if it disagrees with `public/index.html`.

## Tests
| Command | What it proves |
|---|---|
| `npm test` | Backend with a mocked database (valid/hostile orders, tampered prices, CSRF, throttle, currency, safe errors) + page/catalog sync |
| `PGDATABASE=… npm run test:db` | Real handlers against a real PostgreSQL that has migrations 0001+0002 |
| `psql -f test/db.test.sql` | Constraints, FK cascade, atomicity, throttle, privileges |
| `npm run test:e2e` | Browser audit (needs `pip install playwright && playwright install chromium`): errors, overflow, links, images, cart, checkout, preview honesty, mocked live flows at 3 sizes |
| `node test/live-check.js` | Your REAL Supabase project end to end |
